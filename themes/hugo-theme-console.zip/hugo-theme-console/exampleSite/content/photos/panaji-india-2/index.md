+++
image = "panaji-india-2.jpg"
date = "2020-01-07"
title = "Panaji, India"
type = "gallery"
+++

[Panaji](https://en.wikipedia.org/w/index.php?title=Panaji&oldid=949879387), formerly Panjim, is the capital of the Indian state of Goa and the headquarters of North Goa district. It lies on the banks of the Mandovi River estuary in the Ilhas de Goa sub-district (taluka). With a population of 114,759 in the metropolitan area, Panjim is Goa's largest urban agglomeration, ahead of Margão and Vasco da Gama. 
