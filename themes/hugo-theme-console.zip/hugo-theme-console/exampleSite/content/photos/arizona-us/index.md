+++
image = "arizona-us.jpg"
date = "2020-01-21"
title = "Arizona, US"
type = "gallery"
+++

The [Grand Canyon](https://en.wikipedia.org/w/index.php?title=Grand_Canyon&oldid=952699432) 
is a steep-sided canyon carved by the Colorado River in Arizona, United States. 
The canyon is 277 miles (446 km) long, up to 18 miles (29 km) wide and attains a depth of over a mile (6,093 feet or 1,857 meters).